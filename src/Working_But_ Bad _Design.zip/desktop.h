/*
 * desktop.h - the home screen with app icons.
 */
#ifndef DESKTOP_H
#define DESKTOP_H

#include <Arduino.h>

void desktopDraw();
void desktopHandleTouch(int x, int y);

#endif