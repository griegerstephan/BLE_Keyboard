/*
 * settings.h - example second screen.
 */
#ifndef SETTINGS_H
#define SETTINGS_H

#include <Arduino.h>

void settingsDraw();
void settingsHandleTouch(int x, int y);

#endif