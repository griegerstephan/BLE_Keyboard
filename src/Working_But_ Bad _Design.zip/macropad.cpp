/*
 * macropad.cpp - the on-screen macro pad. Loads its buttons from
 * /config.json, draws a tile grid, and sends BLE hotkeys on tap.
 */
#include <TFT_eSPI.h>
#include <BleKeyboard.h>
#include <SD.h>
#include <ArduinoJson.h>
#include <vector>
#include "config.h"
#include "ui.h"
#include "macropad.h"

extern TFT_eSPI tft;
extern BleKeyboard* kb;
extern bool sdReady;

#define ICON_SIZE 48   // all tile icons are 48x48 BMPs

struct Btn {
  String label;
  String image;                    // 48x48 BMP path on the SD card
  std::vector<String> steps;       // each entry is one chord, e.g. "ctrl+a"
};
static std::vector<Btn> buttons;

struct TileZone { int x, y, w, h; };
static std::vector<TileZone> zones;
static int gCols = 2, gRows = 1, gW = 160, gH = 206;
 
// -------------------------------------------------------
// Config loading
// -------------------------------------------------------
static void setDefaults() {
  buttons.clear();
  buttons.push_back({ "Sel & Copy", "/copy.bmp", { "ctrl+a", "ctrl+c" } });
  buttons.push_back({ "Save",       "/save.bmp", { "ctrl+k", "s" } });
} 

static String readConfigRaw() {
  if (!sdReady) return "";
  if (!SD.exists(CONFIG_PATH)) return "";
  File f = SD.open(CONFIG_PATH, FILE_READ);
  if (!f) return "";
  String s;
  while (f.available()) s += (char)f.read();
  f.close();
  return s;
}

void macropadInit() {
  setDefaults();
  String raw = readConfigRaw();
  if (raw.length() == 0) return;
  JsonDocument doc;
  if (deserializeJson(doc, raw)) return;          // bad JSON -> keep defaults

  if (doc["buttons"].is<JsonArray>()) {
    std::vector<Btn> tmp;
    for (JsonObject o : doc["buttons"].as<JsonArray>()) {
      Btn b;
      b.label = o["label"] | "Btn";
      b.image = o["image"] | "";                  // BMP path (optional)
      JsonVariant k = o["keys"];
      if (k.is<JsonArray>()) {
        for (JsonVariant v : k.as<JsonArray>()) {
          const char* s = v | "";
          if (s[0]) b.steps.push_back(String(s));
        }
      } else {
        const char* s = k | "";
        if (s[0]) b.steps.push_back(String(s));
      }
      if (!b.steps.empty()) tmp.push_back(b);
    }
    if (!tmp.empty()) buttons = tmp;               // empty/invalid -> keep defaults
  }
}

// -------------------------------------------------------
// Hotkey parsing & sending
// -------------------------------------------------------
static uint8_t namedKey(const String& k) {
  if (k == "enter" || k == "return") return KEY_RETURN;
  if (k == "tab")                    return KEY_TAB;
  if (k == "esc")                    return KEY_ESC;
  if (k == "space")                  return ' ';
  if (k == "backspace")              return KEY_BACKSPACE;
  if (k == "delete" || k == "del")   return KEY_DELETE;
  if (k == "up")                     return KEY_UP_ARROW;
  if (k == "down")                   return KEY_DOWN_ARROW;
  if (k == "left")                   return KEY_LEFT_ARROW;
  if (k == "right")                  return KEY_RIGHT_ARROW;
  if (k == "home")                   return KEY_HOME;
  if (k == "end")                    return KEY_END;
  if (k.length() >= 2 && k[0] == 'f') {
    int n = k.substring(1).toInt();
    if (n >= 1 && n <= 12) return KEY_F1 + (n - 1);
  }
  return 0;
}

static void sendChord(const String& chord) {
  if (!kb || !kb->isConnected()) return;
  String s = chord; s.toLowerCase();
  String finalKey = "";
  int start = 0;
  while (true) {
    int plus = s.indexOf('+', start);
    String tok = (plus == -1) ? s.substring(start) : s.substring(start, plus);
    tok.trim();
    if      (tok == "ctrl" || tok == "control")            kb->press(KEY_LEFT_CTRL);
    else if (tok == "alt")                                 kb->press(KEY_LEFT_ALT);
    else if (tok == "shift")                               kb->press(KEY_LEFT_SHIFT);
    else if (tok == "win" || tok == "gui" || tok == "cmd") kb->press(KEY_LEFT_GUI);
    else if (tok.length() > 0)                             finalKey = tok;
    if (plus == -1) break;
    start = plus + 1;
  }
  if (finalKey.length() == 1)      kb->press(finalKey[0]);
  else if (finalKey.length() > 1) { uint8_t nk = namedKey(finalKey); if (nk) kb->press(nk); }
  delay(80);
  kb->releaseAll();
}

static void runAction(const std::vector<String>& steps) {
  for (size_t i = 0; i < steps.size(); i++) {
    sendChord(steps[i]);
    if (i + 1 < steps.size()) delay(120);
  }
}

// -------------------------------------------------------
// Grid / drawing
// -------------------------------------------------------
static uint16_t tileColor(int i) {
  static const uint16_t c[] = { TFT_BLUE, TFT_DARKGREEN, TFT_MAROON,
                                TFT_PURPLE, TFT_OLIVE, TFT_NAVY };
  return c[i % 6];
}

static void computeGrid() {
  gCols = 4;
  gRows = 2;
  gW = SW / gCols;                  // 80 px per cell
  gH = (SH - HEADER_H) / gRows;     // 103 px per cell
}

static void drawTile(int i) {
  int col = i % gCols, row = i / gCols;
  int cx = col * gW, cy = HEADER_H + row * gH;   // cell top-left
  zones[i] = { cx, cy, gW, gH };

  // No tile background: clear the cell to the screen colour.
  tft.fillRect(cx, cy, gW, gH, COL_BG);

  // Centred 48x48 icon.
  int ix = cx + (gW - ICON_SIZE) / 2;
  int iy = cy + (gH - ICON_SIZE) / 2;
  if (!uiDrawBmp(buttons[i].image.c_str(), ix, iy)) {
    // Fallback to a small label if the BMP is missing.
    tft.setTextColor(COL_TEXT, COL_BG);
    tft.setTextSize(1);
    int tw = buttons[i].label.length() * 6;
    tft.setCursor(cx + (gW - tw) / 2, cy + gH / 2 - 4);
    tft.print(buttons[i].label);
  }
} 

// -------------------------------------------------------
// Entry points
// -------------------------------------------------------
void macropadDraw() {
  bool conn = kb && kb->isConnected();
  uiClear(COL_BG);
  uiHeader(conn ? "Macro Pad" : "BLE waiting...", conn);
  computeGrid();
  zones.assign(buttons.size(), { 0, 0, 0, 0 });
  for (size_t i = 0; i < buttons.size(); i++) drawTile(i);
}

void macropadHandleTouch(int x, int y) {
  // Tap the header to go back to the desktop.
  if (y < HEADER_H) { switchTo(APP_DESKTOP); return; }

  for (size_t i = 0; i < buttons.size(); i++) {
    if (uiHit(x, y, zones[i].x, zones[i].y, zones[i].w, zones[i].h)) {
      runAction(buttons[i].steps);
      return;
    }
  }
}