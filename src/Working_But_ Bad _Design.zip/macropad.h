/*
 * macropad.h - the BLE macro-pad screen.
 */
#ifndef MACROPAD_H
#define MACROPAD_H

#include <Arduino.h>

void macropadInit();              // load config from SD (call once at boot)
void macropadDraw();
void macropadHandleTouch(int x, int y);
 
#endif