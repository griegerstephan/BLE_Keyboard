/*
 * CYD Wireless Macro Pad
 *
 * Main sketch: owns the global TFT object, SD/BLE, runs the app router,
 * and routes touch events to the active screen.
 *
 * All .ino/.cpp/.h files must live in the same folder for the Arduino
 * IDE to compile them together.
 */
#include <Arduino.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <BleKeyboard.h>
#include <WiFi.h>
#include <WebServer.h>
#include <SD.h>
#include <Preferences.h>

#include "config.h"
#include "ui.h"
#include "desktop.h"
#include "macropad.h"
#include "settings.h"

// ---------- Globals owned here ----------
TFT_eSPI tft = TFT_eSPI();
SPIClass sdSPI(VSPI);          // SD card lives on its own VSPI bus
WebServer server(80);
Preferences prefs;
BleKeyboard* kb = nullptr;
bool sdReady = false;

AppId currentApp = APP_DESKTOP;

String bleName  = "CYD Wireless Tool";
String bleManuf = "Freenove";

// ---------- Touch calibration ----------
int  X_MIN = 200, X_MAX = 3900;
int  Y_MIN = 200, Y_MAX = 3900;
bool SWAP_XY = true, FLIP_X = false, FLIP_Y = false;

// Touch sensitivity: bigger pressure value = firmer press.
// LOWER threshold = a lighter touch registers. Tune (try 80-200).
const int TOUCH_THRESHOLD = 400;

// ---------- Config portal AP ----------
const char* AP_SSID = "CYD-Config";
const char* AP_PASS = "";
const unsigned long HOLD_MS = 2000;

// ==========================================================
//  App router
// ==========================================================
void switchTo(AppId app) {
  currentApp = app;
  switch (app) { 
    case APP_DESKTOP:  desktopDraw();  break;
    case APP_MACROPAD: macropadDraw(); break;
    case APP_SETTINGS: settingsDraw(); break;
    default:           desktopDraw();  break;
  }
}

// Route a tap to whichever screen is active.
static void routeTouch(int x, int y) {
  switch (currentApp) {
    case APP_DESKTOP:  desktopHandleTouch(x, y);  break;
    case APP_MACROPAD: macropadHandleTouch(x, y); break;
    case APP_SETTINGS: settingsHandleTouch(x, y); break;
    default: break;
  }
}

// ==========================================================
//  Built-in XPT2046 touch reader (software SPI)
// ==========================================================
// 12-bit read for any XPT2046 command byte.
static int readReg(uint8_t cmd) {
  digitalWrite(T_CS, LOW);
  for (int i = 8; i > 0; i--) {
    digitalWrite(T_DIN, (cmd >> (i - 1)) & 1);
    digitalWrite(T_CLK, HIGH); digitalWrite(T_CLK, LOW);
  }
  digitalWrite(T_CLK, HIGH); digitalWrite(T_CLK, LOW);   // busy clock
  int data = 0;
  for (int i = 12; i > 0; i--) {
    data += digitalRead(T_DOUT) << (i - 1);
    digitalWrite(T_CLK, HIGH); digitalWrite(T_CLK, LOW);
  }
  digitalWrite(T_CS, HIGH);
  digitalWrite(T_DIN, LOW);
  return data;
}

// Pen pressure. ~0 when not touched, rises as the press firms up.
static int readPressure() {
  int z1 = readReg(0xB0);
  int z2 = readReg(0xC0);
  return z1 + 4095 - z2;
}

static bool readTouch(int &sx, int &sy) {
  if (readPressure() < TOUCH_THRESHOLD) return false;   // not pressed

  // Average a few samples for a steady coordinate.
  const int N = 4;
  long xr = 0, yr = 0;
  for (int i = 0; i < N; i++) { xr += readReg(0xD0); yr += readReg(0x90); }
  xr /= N; yr /= N;
  if (!(xr > 0 && xr < 4095 && yr > 0 && yr < 4095)) return false;

  float fx = constrain((xr - X_MIN) / float(X_MAX - X_MIN), 0.0f, 1.0f);
  float fy = constrain((yr - Y_MIN) / float(Y_MAX - Y_MIN), 0.0f, 1.0f);
  if (FLIP_X) fx = 1.0f - fx;
  if (FLIP_Y) fy = 1.0f - fy;
  if (SWAP_XY) { sx = fy * SW; sy = fx * SH; }
  else         { sx = fx * SW; sy = fy * SH; }
  return true;
}

// ==========================================================
//  SD + config portal
// ==========================================================
static bool mountSD() {
  sdSPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);
  sdReady = SD.begin(SD_CS, sdSPI);
  return sdReady;
}

static String readConfigRaw() {
  return "";

  if (!sdReady || !SD.exists(CONFIG_PATH)) return "";
  File f = SD.open(CONFIG_PATH, FILE_READ);
  if (!f) return "";
  String s;
  while (f.available()) s += (char)f.read();
  f.close();
  return s;
}

static bool writeConfigRaw(const String& body) {
  if (!sdReady) return false;
  File f = SD.open("/config.tmp", FILE_WRITE);
  if (!f) return false;
  f.print(body);
  f.close();
  SD.remove(CONFIG_PATH);
  return SD.rename("/config.tmp", CONFIG_PATH);
}

static void handleRoot() {
  String c = readConfigRaw();
  if (c.length() == 0) {
    c = "{\n  \"ble_name\": \"CYD Wireless Tool\",\n"
        "  \"ble_manuf\": \"Freenove\",\n"
        "  \"buttons\": [\n"
        "    { \"label\": \"Build\",        \"keys\": \"ctrl+alt+b\" },\n"
        "    { \"label\": \"Build+Upload\", \"keys\": \"ctrl+alt+u\" },\n"
        "    { \"label\": \"Sel + Copy\",   \"keys\": [\"ctrl+a\", \"ctrl+c\"] },\n"
        "    { \"label\": \"Save\",         \"keys\": \"ctrl+s\" }\n"
        "  ]\n}\n";
  }
  c.replace("&", "&amp;");
  c.replace("<", "&lt;");
  String html =
    "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'>"
    "<style>body{font-family:sans-serif;margin:16px}"
    "textarea{width:100%;height:55vh;font-family:monospace;font-size:14px}"
    "button{padding:10px 16px;margin-top:8px;font-size:16px}code{background:#eee;padding:1px 4px}</style>"
    "<h2>CYD Macro Pad &mdash; config</h2>"
    "<form method=POST action=/save>"
    "<textarea name=cfg>" + c + "</textarea><br>"
    "<button>Save &amp; reboot</button></form>";
  if (!sdReady)
    html += "<p style='color:#c00'>WARNING: SD card not detected.</p>";
  server.send(200, "text/html", html);
}

static void handleSave() {
  String body = server.arg("cfg");
  if (writeConfigRaw(body)) {
    server.send(200, "text/html", "Saved. Rebooting...");
    delay(500);
    ESP.restart();
  } else {
    server.send(500, "text/html", "SD write failed. <a href=/>back</a>");
  }
}

static void runConfigMode() {
  return;
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  IPAddress ip = WiFi.softAPIP();
  tft.fillScreen(TFT_NAVY);
  tft.setTextColor(TFT_WHITE);
  tft.setTextSize(3); tft.setCursor(10, 20);  tft.print("CONFIG MODE");
  tft.setTextSize(2);
  tft.setCursor(10, 90);  tft.print(String("WiFi: ") + AP_SSID);
  tft.setCursor(10, 160); tft.print(String("http://") + ip.toString());
  server.on("/", handleRoot);
  server.on("/save", HTTP_POST, handleSave);
  server.begin();
  for (;;) { server.handleClient(); delay(2); }
}
 
// ==========================================================
//  Setup
// ==========================================================
void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  pinMode(T_CS, OUTPUT);  digitalWrite(T_CS, HIGH);
  pinMode(T_CLK, OUTPUT); digitalWrite(T_CLK, LOW);
  pinMode(T_DIN, OUTPUT); digitalWrite(T_DIN, LOW);
  pinMode(T_DOUT, INPUT);

  tft.init();
  tft.setRotation(1);

  mountSD();

  prefs.begin("cyd", false);
  bool wantConfig = prefs.getBool("cfgmode", false);
  prefs.putBool("cfgmode", false);
  prefs.end();
  if (wantConfig) runConfigMode();   // never returns

  macropadInit();                    // load macro-pad buttons from SD

  kb = new BleKeyboard(std::string(bleName.c_str()),
                       std::string(bleManuf.c_str()), 100);
  kb->begin();

  switchTo(APP_DESKTOP);
  Serial.println("ready");
}

// ==========================================================
//  Loop
// ==========================================================
int lastButtonState = HIGH;
unsigned long pressStart = 0;
bool configArmed = false;
bool lastConnected = false;
bool touchLatched = false;

void loop() {
  // Redraw the active screen when BLE connection state changes
  // (keeps the header in sync).
  bool conn = kb && kb->isConnected();
  if (conn != lastConnected) { lastConnected = conn; switchTo(currentApp); }

  // ----- Touch: fire once per touch on release, routed to active screen -----
  int sx, sy;
  if (readTouch(sx, sy)) {
    if (!touchLatched) {
      routeTouch(sx, sy);
      touchLatched = true;
    }
  } else {
    touchLatched = false;
  }

  // ----- BOOT button: hold 2s = config mode -----
  int btn = digitalRead(BUTTON_PIN);
  if (btn == LOW && lastButtonState == HIGH) { pressStart = millis(); configArmed = false; }

  if (btn == LOW && !configArmed && millis() - pressStart > HOLD_MS) {
    configArmed = true;
    tft.fillScreen(TFT_NAVY);
    tft.setTextColor(TFT_WHITE); tft.setTextSize(3);
    tft.setCursor(10, 90); tft.print("Config...");
    prefs.begin("cyd", false); prefs.putBool("cfgmode", true); prefs.end();
    delay(400);
    ESP.restart();
  }

  lastButtonState = btn;
  delay(10);
}