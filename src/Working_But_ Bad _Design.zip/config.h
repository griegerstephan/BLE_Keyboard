/*
 * config.h - shared constants for the whole project
 */
#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// Screen dimensions (landscape, rotation 1) - CYD 2.8" ST7789
#define SW 320
#define SH 240

// Layout
#define HEADER_H 34

// Colours (RGB565)
#define COL_BG          0x0000
#define COL_TEXT        0xFFFF
#define COL_HEADER_OK   0x03E0
#define COL_HEADER_WAIT 0xF800
#define COL_TILE        0x001F
#define COL_PRESSED     0xFFFF
#define COL_PANEL       0x39E7

// ---- Pins ----
#define BUTTON_PIN 0     // BOOT button
#define SD_SCK  18       // SD on VSPI
#define SD_MISO 19
#define SD_MOSI 23
#define SD_CS   5
#define T_CS  33         // XPT2046 touch (bit-banged)
#define T_CLK 25
#define T_DIN 32
#define T_DOUT 39

// Config portal
#define CONFIG_PATH "/config.json"

// Every screen/app has an ID. Add new apps here as you build them.
enum AppId {
  APP_DESKTOP,
  APP_MACROPAD,
  APP_SETTINGS
};

// Defined in main.cpp - lets any module request a screen change.
void switchTo(AppId app);

#endif