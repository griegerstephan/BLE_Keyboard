/*
 * desktop.cpp - the home screen. Draws the icon grid and routes taps
 * to the matching app via switchTo().
 */
#include <TFT_eSPI.h>
#include "config.h"
#include "ui.h"
#include "desktop.h"

extern TFT_eSPI tft;

#define ICON_W       120
#define ICON_H       70
#define ICON_COLS    2
#define ICON_X_START 30
#define ICON_Y_START 70
#define ICON_X_GAP   20
#define ICON_Y_GAP   24

static const char* appNames[2] = { "Macro Pad", "Settings" };

// Which app each icon launches.
static AppId iconTargets[2] = { APP_MACROPAD, APP_SETTINGS };

struct IconZone { int x, y, w, h; };
static IconZone zones[2];

static void drawIcon(int idx) {
  int col = idx % ICON_COLS;
  int row = idx / ICON_COLS;
  int x = ICON_X_START + col * (ICON_W + ICON_X_GAP);
  int y = ICON_Y_START + row * (ICON_H + ICON_Y_GAP);

  zones[idx] = { x, y, ICON_W, ICON_H };
  uiButton(x, y, ICON_W, ICON_H, appNames[idx], COL_TILE, false);
}

void desktopDraw() {
  uiClear(COL_BG);
  uiHeader("Desktop", true);
  for (int i = 0; i < 2; i++) drawIcon(i);
}

void desktopHandleTouch(int x, int y) {
  for (int i = 0; i < 2; i++) {
    if (uiHit(x, y, zones[i].x, zones[i].y, zones[i].w, zones[i].h)) {
      switchTo(iconTargets[i]);
      return;
    }
  }
}