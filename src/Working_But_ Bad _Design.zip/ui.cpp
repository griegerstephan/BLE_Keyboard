/*
 * ui.cpp - implementation of the shared drawing primitives.
 */
#include <TFT_eSPI.h>
#include <SD.h>
#include "config.h"
#include "ui.h"

extern TFT_eSPI tft;   // the global screen object from main.cpp
extern bool sdReady;   // set in main.cpp once the SD card is mounted

void uiClear(uint16_t color) {
  tft.fillScreen(color);
}

void uiHeader(const char* title, bool ok) {
  tft.fillRect(0, 0, SW, HEADER_H, ok ? COL_HEADER_OK : COL_HEADER_WAIT);
  tft.drawFastHLine(0, HEADER_H, SW, COL_TEXT);
  tft.setTextColor(COL_TEXT);
  tft.setTextSize(2);
  tft.setCursor(6, 8);
  tft.print(title);
}

void uiTitle(const char* title) {
  tft.setTextColor(COL_TEXT, COL_BG);
  tft.setTextSize(2);
  int tw = strlen(title) * 12;
  tft.setCursor((SW - tw) / 2, 8);
  tft.print(title);
}

void uiButton(int x, int y, int w, int h, const char* label,
              uint16_t fill, bool pressed) {
  uint16_t c = pressed ? COL_PRESSED : fill;
  tft.fillRoundRect(x, y, w, h, 6, c);
  tft.drawRoundRect(x, y, w, h, 6, COL_TEXT);
  tft.setTextColor(pressed ? COL_BG : COL_TEXT);
  tft.setTextSize(2);
  int tw = strlen(label) * 12;
  int tx = x + (w - tw) / 2; if (tx < x + 6) tx = x + 6;
  tft.setCursor(tx, y + h / 2 - 8);
  tft.print(label);
}

void uiPanel(int x, int y, int w, int h) {
  tft.fillRect(x, y, w, h, COL_PANEL);
  tft.drawRect(x, y, w, h, COL_TEXT);
}

bool uiHit(int px, int py, int x, int y, int w, int h) {
  return (px >= x && px <= x + w && py >= y && py <= y + h);
}

// -------------------------------------------------------
// BMP loader (24/32-bit, uncompressed, from the SD card)
// -------------------------------------------------------
// Scratch buffers sized for a full-width row so any reasonable icon fits.
static uint8_t  rowBuf[SW * 4];
static uint16_t lineBuf[SW];

static uint16_t bmpRead16(File &f) {
  uint16_t v = 0;
  f.read((uint8_t*)&v, 2);   // ESP32 + BMP are both little-endian
  return v;
}
static uint32_t bmpRead32(File &f) {
  uint32_t v = 0;
  f.read((uint8_t*)&v, 4);
  return v;
}

bool uiDrawBmp(const char* path, int x, int y) {
  if (!path || !path[0]) { Serial.println("[bmp] empty path"); return false; }
  if (!sdReady)          { Serial.printf("[bmp] SD not ready (%s)\n", path); return false; }

  File f = SD.open(path, FILE_READ);
  if (!f) { Serial.printf("[bmp] open failed: %s\n", path); return false; }

  if (bmpRead16(f) != 0x4D42) {                             // 'BM'
    Serial.printf("[bmp] not a BMP: %s\n", path); f.close(); return false;
  }
  bmpRead32(f);                              // file size   (skip)
  bmpRead32(f);                              // reserved    (skip)
  uint32_t dataOffset  = bmpRead32(f);       // pixel data offset
  bmpRead32(f);                              // DIB hdr size (skip)
  int32_t  w           = (int32_t)bmpRead32(f);
  int32_t  h           = (int32_t)bmpRead32(f);
  bmpRead16(f);                              // planes      (skip)
  uint16_t bpp         = bmpRead16(f);
  uint32_t compression = bmpRead32(f);

  if ((bpp != 24 && bpp != 32) || compression != 0) {
    Serial.printf("[bmp] bad format %s: bpp=%u comp=%u\n", path, bpp, compression);
    f.close(); return false;
  }

  bool topDown = false;
  if (h < 0) { h = -h; topDown = true; }
  if (w <= 0 || w > SW || h <= 0 || h > SH) {
    Serial.printf("[bmp] size out of range %s: %dx%d\n", path, w, h);
    f.close(); return false;
  }

  int bpb     = bpp / 8;
  int rowSize = (w * bpb + 3) & ~3;          // rows padded to 4 bytes

  bool prevSwap = tft.getSwapBytes();
  tft.setSwapBytes(true);                     // pushImage expects swapped 565
  for (int r = 0; r < h; r++) {
    int srcRow = topDown ? r : (h - 1 - r);  // BMP is bottom-up by default
    f.seek(dataOffset + (uint32_t)srcRow * rowSize);
    f.read(rowBuf, rowSize);
    for (int c = 0; c < w; c++) {
      uint8_t b  = rowBuf[c * bpb + 0];
      uint8_t g  = rowBuf[c * bpb + 1];
      uint8_t rr = rowBuf[c * bpb + 2];      // alpha (if 32-bit) ignored
      lineBuf[c] = tft.color565(rr, g, b);
    }
    tft.pushImage(x, y + r, w, 1, lineBuf);
  }
  tft.setSwapBytes(prevSwap);
  f.close();
  Serial.printf("[bmp] drew %s (%dx%d) at %d,%d\n", path, w, h, x, y);
  return true;
}