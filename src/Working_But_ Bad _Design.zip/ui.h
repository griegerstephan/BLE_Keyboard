/*
 * ui.h - shared drawing primitives used by every screen.
 */
#ifndef UI_H
#define UI_H

#include <Arduino.h>

// --- Background & chrome ---------------------------------------------
void uiClear(uint16_t color);
void uiHeader(const char* title, bool ok);
void uiTitle(const char* title);

// --- Widgets ---------------------------------------------------------
void uiButton(int x, int y, int w, int h, const char* label,
              uint16_t fill, bool pressed);
void uiPanel(int x, int y, int w, int h);
bool uiHit(int px, int py, int x, int y, int w, int h);

// --- Images ----------------------------------------------------------
// Draws an uncompressed 24- or 32-bit BMP from the SD card with its
// top-left corner at (x, y). Returns false if the SD card isn't ready,
// the file is missing, or the format isn't supported.
bool uiDrawBmp(const char* path, int x, int y);

#endif 