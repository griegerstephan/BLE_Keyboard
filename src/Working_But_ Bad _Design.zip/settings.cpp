/*
 * settings.cpp - a stub second screen, to show how a new screen plugs in.
 * Copy this pair (.h/.cpp), add an AppId in config.h, and wire it into
 * switchTo()/routeTouch() in main.cpp.
 */
#include <TFT_eSPI.h>
#include "config.h"
#include "ui.h"
#include "settings.h"

extern TFT_eSPI tft;

struct Zone { int x, y, w, h; };
static Zone backZone;

void settingsDraw() {
  uiClear(COL_BG);
  uiHeader("Settings", true);

  uiPanel(20, 60, SW - 40, 100);
  tft.setTextColor(COL_TEXT, COL_PANEL);
  tft.setTextSize(2);
  tft.setCursor(36, 95);
  tft.print("Nothing here yet");

  backZone = { 20, SH - 50, 120, 36 };
  uiButton(backZone.x, backZone.y, backZone.w, backZone.h,
           "Back", COL_TILE, false);
}

void settingsHandleTouch(int x, int y) {
  if (uiHit(x, y, backZone.x, backZone.y, backZone.w, backZone.h)) {
    switchTo(APP_DESKTOP);
    return;
  }
}